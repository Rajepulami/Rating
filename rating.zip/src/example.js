const example = {
	attributes: {
		color: "#ffcc01",
	},
};

export default example;
